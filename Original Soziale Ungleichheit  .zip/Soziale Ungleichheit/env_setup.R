### sourcing this file can help set up the environment needed for this project. ###
## Warning: The `interval` package requires supporting packages that do not belong
## to CRAN. It may cause problem due to different R versions.
## In the project, we use R 4.4.1.

## If problems with installing Icens and Interval occur, please check R version.

##把工作目录设置为当前脚本所在的文件夹
setwd(here::here())

##所需包列表
packages <- c(
  "tidyr",
  "dplyr",
  "colorspace",
  "stringr",
  "ggrepel",
  "lubridate",
  "ggplot2",
  "plotly",
  "purrr",
  "knitr",
  "pROC",
  "rpart",
  "survival",
  "ggsurvfit",
  "survminer",
  "moments",
  "magrittr",
  "kableExtra",
  "readr",
  "patchwork",
  "epitools",
  "RColorBrewer",
  "icenReg",
  "interval",
  "tidyverse"
)

## 
for (pkg in packages) {
  if (!require(pkg, character.only = TRUE)) {
    stop(paste0(
      "Package '", pkg, "' is not installed. ",
      "Please install it with install.packages('", pkg, "') in Console."
    ))
  }
}


## 
folder_path <- "Data/"  
csv_files <- list.files(
  path = folder_path, 
  pattern = "\\.csv$", 
  full.names = TRUE,
  ignore.case = TRUE
)
for (file in csv_files) {
  var_name <- file
  var_name <- gsub("^Data/", "", var_name)
  var_name <- gsub("\\.csv$", "", var_name)
  var_name <- gsub("-", "_", var_name)
  data <- read.csv(file)
  assign(var_name, data)
}






