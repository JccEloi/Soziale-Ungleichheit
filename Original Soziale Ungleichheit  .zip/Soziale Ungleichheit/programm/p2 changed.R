library(ggplot2)
library(dplyr)
library(cowplot)   # 用来提取并拼接 legend

# 你给的映射
continent_map <- list(
  "Europe (WID)"        = c("Denmark", "Germany", "Poland"),
  "Asia (WID)"          = c("Singapore", "South Korea", "Indonesia", "China"),
  "Africa (WID)"        = c("Algeria", "Egypt", "South Africa"),
  "North America (WID)" = c("United States", "Canada"),
  "Latin America (WID)" = c("Argentina", "Colombia", "Peru"),
  "Oceania (WID)"       = c("New Zealand", "Australia")
)

## 1) 主图：你的原始 p1.2，但关掉 legend ---------------------------
p_main <- ggplot(
  gini_before_selected,
  aes(x = Year, y = Gini_beforetax, color = Country)
) +
  geom_line(linewidth = 0.9, alpha = 0.9) +
  scale_color_manual(values = country_colors) +
  facet_wrap(
    ~ Region,
    ncol = 3,
    scales = "fixed"
  ) +
  labs(
    title = "Before-tax Gini coefficients by country and region(2000-2023)",
    x = "Year",
    y = "Gini Coefficient (Before Tax)",
    color = "Country"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title  = element_text(hjust = 0.5, face = "plain"),
    axis.title  = element_text(size = 14),
    axis.text   = element_text(size = 12),
    strip.text  = element_text(hjust = 0.5),
    legend.position = "none"   # ⭐ 关键：主图不再自己画 legend
  )

## 2) 工具函数：根据一组国家名生成该组的 legend ------------------
make_legend <- function(countries) {
  df <- data.frame(
    x       = 1,
    y       = 1,
    Country = factor(countries, levels = countries)
  )
  
  p_legend <- ggplot(df, aes(x, y, colour = Country)) +
    geom_point(size = 3) +
    scale_color_manual(values = country_colors) +
    guides(colour = guide_legend(nrow = 1, byrow = TRUE)) +
    theme_void() +
    theme(
      legend.position = "bottom",
      legend.title    = element_blank(),
      legend.text     = element_text(size = 9),
      legend.key.size = unit(0.4, "lines")
    )
  
  cowplot::get_legend(p_legend)   # ⭐ 只要 legend 这一块
}

## 3) 为六个大洲分别做 legend（按 continent_map） -------------------
leg_europe  <- make_legend(continent_map[["Europe (WID)"]])
leg_asia    <- make_legend(continent_map[["Asia (WID)"]])
leg_africa  <- make_legend(continent_map[["Africa (WID)"]])
leg_na      <- make_legend(continent_map[["North America (WID)"]])
leg_latam   <- make_legend(continent_map[["Latin America (WID)"]])
leg_oceania <- make_legend(continent_map[["Oceania (WID)"]])

## 4) 把六个 legend 拼成 2 行 × 3 列 ------------------------------
# 第一行：Europe | Asia | Africa
# 第二行：North America | Latin America | Oceania
legends_grid <- cowplot::plot_grid(
  leg_europe, leg_asia, leg_africa,
  leg_na,     leg_latam, leg_oceania,
  ncol = 3,
  align = "hv",
  legend.vgap = unit(12, "pt")
  
)

## 5) 主图 + legend 区域 合成最终 p1.2 ---------------------------
p1.2 <- cowplot::plot_grid(
  p_main,
  legends_grid,
  ncol = 1,
  rel_heights = c(7.5, 2)   # 可以微调整体“图：图例”高度比例
)

p1.2

