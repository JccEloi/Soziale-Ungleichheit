library(dplyr)
library(ggplot2)
library(viridis)

breaks_q <- quantile(
  merged_homi_gini$Gini_aftertax,
  probs = seq(0, 1, length.out = 6),
  na.rm = TRUE
)

breaks_q

merged_homi_gini2 <- merged_homi_gini %>%
  mutate(
    Gini_bin = cut(
      Gini_aftertax,
      breaks = breaks_q,
      include.lowest = TRUE,
      dig.lab = 4
    )
  )

table(merged_homi_gini2$Gini_bin)

merged_homi_gini2 %>%
  filter(!is.na(Gini_bin)) %>%
  ggplot(
    aes(
      x = Gini_bin,
      y = `Homicide rate per 100,000 population - sex: Total - age: Total`,
      fill = Gini_bin
    )
  ) +
  geom_boxplot(
    width = 0.6,
    outlier.shape = NA,
    color = "grey20"
  ) +
  geom_jitter(
    width = 0.25,
    size = 2.0,
    alpha = 0.7,
    color = "grey15"
  ) +
  
  # ★★★ 加：中位数折线 ★★★
  stat_summary(
    fun = median,
    geom = "line",
    aes(group = 1),
    color = "#084C8D",
    linewidth = 1
  ) +
  stat_summary(
    fun = median,
    geom = "point",
    color = "#084C8D",
    size = 2.5
  ) +
  
  scale_fill_manual(
    name = "Gini range",
    values = c(
      "#FFF5F0",
      "#FEE0D2",
      "#FC9272",
      "#FB6A4A",
      "#CB181D"
    )
  ) +
  
  labs(
    title = "Homicide Rate by Post-tax Gini Coefficient (2021)",
    subtitle = "Gini grouped into bins; points show individual countries\nBlue line shows bin-wise median homicide rate",
    x = "Post-tax Gini coefficient (binned)",
    y = "Homicide rate per 100,000 population"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(size = 15, face = "bold", hjust = 0.5, color = "black",
                              margin = margin(b = 4)),
    plot.subtitle = element_text(size = 13, hjust = 0.5, colour = "grey30"),
    axis.title = element_text(size = 14),
    axis.text.x = element_text(angle = 35, hjust = 1),
    panel.grid.major.x = element_blank(),
    legend.position = "right",
    legend.justification = "bottom",
    legend.box.just = "bottom",
    legend.title = element_text(size = 8.5, face = "bold"),
    legend.text = element_text(size = 7.5)
  ) +
  coord_cartesian(ylim = c(0, 15)) 


p3.2 <- merged_homi_gini2
print(p3.2)