p2.2 <- ggplot(gini_before_selected, 
       aes(x = Year, y = reorder(Country, Gini_beforetax), fill = Gini_beforetax)
  ) +
  geom_tile() +
  scale_fill_distiller(type = "seq", palette = "OrRd", direction = 1) +
  labs(
    title = "Before-tax Gini Coefficient (2000–2023)",
    x = "Year", y = "Country", fill = "Gini"
  ) +
  theme_minimal(base_size = 11)+
  theme(
    plot.title = element_text( hjust = 0.5)
  )
  
print(p2.2)

ggsave("~/Desktop/p3.svg",
       +        plot = last_plot(),
       +        width = 8, height = 6)
