##生成国家颜色公式
generate_country_colors <- function(region, countries,
                                    l_range = c(40, 85),
                                    c_range = c(80, 30),
                                    power = 1.2,
                                    reverse = FALSE) {
  
  base_color <- region_colors[region]
  
  n <- length(countries)
  if (n == 0) return(character(0))
  if (n == 1) { names(base_color) <- countries; return(base_color) }
  
  rgb_vals <- col2rgb(base_color) / 255
  hsv_vals <- rgb2hsv(rgb_vals[1], rgb_vals[2], rgb_vals[3])
  h <- hsv_vals["h", ] * 360
  
  cols <- colorspace::sequential_hcl(
    n, h = h,
    c = c(c_range[1], c_range[2]),
    l = c(l_range[1], l_range[2]), 
    power = power
  )
  
  if (reverse) cols <- rev(cols)
  names(cols) <- countries
  cols
} 

## 国家颜色保存
country_colors <- unlist(lapply(names(continent_map), function(region) {
  generate_country_colors(region, continent_map[[region]])
}))

barplot(rep(1, length(country_colors)), col = country_colors,
        border = NA, space = 0, axes = FALSE)

text(x = seq_along(country_colors) - 0.5,
    y = 1.05,
    labels = names(country_colors),
    srt = 90,
    cex = 0.8)


     
p1.2 <- ggplot(
  gini_before_selected,
  aes(x = Year, y = Gini_beforetax, color = Country)
) +
  geom_line(linewidth = 0.9, alpha = 0.9) +
  scale_color_manual(values = country_colors) +
  facet_wrap(
    ~ Country,
    ncol = 3,
    scales = "fixed"
  ) +
  labs(
    title = "Economic Inequality Trends by Continent (2000–2023)",
    subtitle = "Before-tax Gini coefficients by country and region",
    x = "Year",
    y = "Gini Coefficient (Before Tax)",
    color = "Country"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    # 标题样式
    plot.title = element_text(size = 22, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 15, hjust = 0.5, margin = margin(b = 15)),
    #坐标轴
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 12),
    # 分面标题
    strip.text = element_text(size = 18, face = "bold"),
    # 图例放在整张图片底部 + 控制大小
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.title = element_text(size = 10),
    legend.text = element_text(size = 9),
    legend.key.size = unit(0.7, "lines"),
    legend.box = "horizontal",
    # 增加图例与图之间距离
    legend.margin = margin(t = -10)
  ) +
  guides(
    color = guide_legend(
      nrow = 3, # 图例分成几行（你可以改成 4 / 5）
      byrow = TRUE
    )
  ) 

print(p1.2)
