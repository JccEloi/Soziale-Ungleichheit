##规定颜色
region_colors <- c(
  "World" = "#000000", #黑
  "Europe (WID)" = "#BB5500", # 橙棕
  "Asia (WID)" = "#1B9E77", # 青绿
  "Africa (WID)" = "#66A61E", # 草绿（亮度更高）
  "North America (WID)" = "#7570B3", # 紫蓝
  "Latin America (WID)" = "#E7298A", # 洋红
  "Oceania (WID)" = "#A6761D" # 金棕
) 

p1.1 <- ggplot(gini_region_before,
               aes(x = Year, 
                   y = Gini_beforetax, 
                   color = Country, 
                   group = Country)) +
  geom_line(linewidth = 1.7) +
  scale_color_manual(values = region_colors, name = "Region") +
  labs(
    title = "Evolution of Economic Inequality Across the World and Continents",
    subtitle = "Based on before-tax Gini coefficients",
    x = "Year",
    y = "Gini Coefficient (Before Tax)",
    color = "Region"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    # --------------------------
    # 图例设置
    # --------------------------
    legend.position = "right",
    legend.justification = "bottom",
    legend.box.just = "bottom",
    legend.background = element_rect(fill = "transparent", color = NA),
    legend.key.size = unit(1, "lines"),
    legend.title = element_text(size = 8.5, face = "bold"),
    legend.text = element_text(size = 7.5),
    # --------------------------
    # 坐标轴字体设置
    # --------------------------
    axis.title = element_text(size = 9),
    axis.text = element_text(size = 8),
    # --------------------------
    # 标题字体设置
    # --------------------------
    plot.title = element_text(size = 15, face = "bold", hjust = 0.5, color = "black",
                              margin = margin(b = 4)),
    plot.subtitle = element_text(size = 12, hjust = 0.5, color = "gray40",
                                 margin = margin(b = 8)),
    plot.margin = margin(t = 12, r = 15, b = 12, l = 15)
  )
    

print(p1.1)


